/* $OpenBSD: version.h,v 1.101 2024/03/11 04:59:47 djm Exp $ */

#define SSH_VERSION	"OpenSSH_9.7"
